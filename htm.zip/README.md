# 🥊 TAJ WARRIOR MMA — Live Streaming Platform

Современный сайт для прямых трансляций боёв MMA с интеграцией Telegram канала.  
Сделано на **React + TailwindCSS + shadcn/ui + lucide-react**.

## 🚀 Возможности
- 🔴 Онлайн-стримы (YouTube, Twitch и т.д.)
- 📱 Адаптивный дизайн (мобильные и десктопные устройства)
- 🎥 Несколько рингов/залов
- 🚨 Подписка в Telegram через кнопку
- ⚡ Анимации и современный UI

## ⚙️ Установка и запуск
```bash
git clone https://github.com/ВАШ_АККАУНТ/taj-warrior-mma.git
cd taj-warrior-mma
npm install
npm start
```

## 📝 Настройка
1. В `App.js` замените ссылки на свои стримы.
2. Telegram кнопка уже ведёт на: https://t.me/tajwarrior
3. Можно добавить REACT_APP_BACKEND_URL в `.env`.

## 📜 Лицензия
MIT — свободно используйте и дорабатывайте 🚀
