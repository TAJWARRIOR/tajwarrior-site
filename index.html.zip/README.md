# 🥊 TAJ WARRIOR MMA

Добро пожаловать в **TAJ WARRIOR MMA** — проект на Next.js для прямых трансляций боёв MMA.

## 🚀 Запуск проекта

1. Установите зависимости:
```bash
npm install
```

2. Запустите dev-сервер:
```bash
npm run dev
```

3. Откройте в браузере:
```
http://localhost:3000
```

## 📂 Структура проекта

```
taj_warrior_next/
├── app/
│   └── page.tsx         # Главная страница
├── components/
│   ├── VideoPlayer.tsx  # Видеоплеер
│   ├── TelegramButton.tsx
│   ├── FightingCage.tsx
│   └── Navigation.tsx
├── public/              # Статические файлы
├── styles/              # Tailwind стили
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── next.config.js
```

## 📱 Возможности

- Прямой эфир боёв
- Кнопка подписки на Telegram
- Карточки с информацией о боях
- Адаптивный дизайн (Tailwind CSS)

---
© 2025 TAJ WARRIOR | Все права защищены
